package com.js.mpchartexample.exercise;

/**
 * Created by js_gg on 2017/6/22.
 */

public class ChartBean {
    private int value;

    private int year;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
