package com.js.graphicdisplay.util;

/**
 *
 * Created by apple on 2017/7/19.
 */

public enum SortState {

    NOT_SORTABLE,
    SORTABLE,
    SORTED_ASC,
    SORTED_DESC
}
