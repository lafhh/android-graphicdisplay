package com.js.graphicdisplay.api;

/**
 * Created by js_gg on 2017/6/18.
 */

public interface Infermation {

    String getName();
}
