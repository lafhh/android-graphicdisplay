package com.js.graphicdisplay.util;

import android.graphics.Color;

/**
 * Created by apple on 2017/7/5.
 */

public class ColorTemplate {

    public static final int[] TEMPLETE_COLOR = {
            Color.rgb(255, 210, 139),
//            Color.rgb(233, 210, 188),
//            Color.rgb(205, 214, 222),
            Color.rgb(101, 201, 228),
            Color.rgb(174, 151, 206),
            Color.rgb(189, 219, 127),
            Color.rgb(239, 140, 136)
    };
}
